package com.healthcare.appointment.service;

import com.healthcare.appointment.dto.AppointmentDTO;
import java.util.List;

public interface AppointmentService {
    AppointmentDTO createAppointment(AppointmentDTO dto);
    List<AppointmentDTO> getUpcomingAppointments(String patientName);
    AppointmentDTO cancelAppointment(int appointmentId);
}
