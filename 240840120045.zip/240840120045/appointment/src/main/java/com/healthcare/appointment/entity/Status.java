package com.healthcare.appointment.entity;

public enum Status {
    SCHEDULED,
    CANCELED,
    COMPLETED,
    RESCHEDULED
}
