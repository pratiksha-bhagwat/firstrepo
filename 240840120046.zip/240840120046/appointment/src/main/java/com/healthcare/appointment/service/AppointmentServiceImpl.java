package com.healthcare.appointment.service;

import com.healthcare.appointment.dto.AppointmentDTO;
import com.healthcare.appointment.entity.Appointment;
import com.healthcare.appointment.entity.Status;
import com.healthcare.appointment.repository.AppointmentRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class AppointmentServiceImpl implements AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Override
    public AppointmentDTO createAppointment(AppointmentDTO dto) {
        Appointment appointment = new Appointment();
        BeanUtils.copyProperties(dto, appointment);
        appointment.setCreateDateTime(LocalDateTime.now());
        appointment.setStatus(Status.SCHEDULED);
        Appointment savedAppointment = appointmentRepository.save(appointment);
        BeanUtils.copyProperties(savedAppointment, dto);
        return dto;
    }

    @Override
    public List<AppointmentDTO> getUpcomingAppointments(String patientName) {
        List<Appointment> appointments = appointmentRepository.findByPatientNameAndStatus(patientName, Status.SCHEDULED);
        List<AppointmentDTO> dtoList = new ArrayList<>();
        for (Appointment appointment : appointments) {
            AppointmentDTO dto = new AppointmentDTO();
            BeanUtils.copyProperties(appointment, dto);
            dtoList.add(dto);
        }
        return dtoList;
    }

    @Override
    public AppointmentDTO cancelAppointment(int appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment with ID " + appointmentId + " not found"));
        appointment.setStatus(Status.CANCELED);
        appointment.setCancelDateTime(LocalDateTime.now());
        Appointment canceledAppointment = appointmentRepository.save(appointment);
        AppointmentDTO dto = new AppointmentDTO();
        BeanUtils.copyProperties(canceledAppointment, dto);
        return dto;
    }
}
