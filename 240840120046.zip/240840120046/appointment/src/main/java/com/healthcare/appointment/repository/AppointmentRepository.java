package com.healthcare.appointment.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.healthcare.appointment.entity.Appointment;
import com.healthcare.appointment.entity.Status;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
    List<Appointment> findByPatientNameAndStatus(String patientName, Status status);
    List<Appointment> findByStatus(Status status);
}
